import { Locator, Page } from "@playwright/test";
import { BasePage } from "../basePage";
import { SalesHomePage } from "../salesHomePage";
import { AppNameConstant } from "../../constants/appNameConstants";

export class AppLauncherComponent extends BasePage {
  loadThePage(): Promise<void> {
    throw new Error("Method not implemented.");
  }
  verifyThePageIsLoaded(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  readonly viewAllButtonInAppLauncher: Locator;
  readonly salesTileInExpandedAppLauncher: Locator;
  readonly appTilesLocatorInExpandedAppLauncher: Locator;

  constructor(page: Page) {
    super(page);
    this.viewAllButtonInAppLauncher = this.page
      .locator("button")
      .filter({ hasText: "View All" });
    this.salesTileInExpandedAppLauncher = this.page.locator(
      "one-app-launcher-app-tile[data-name='Sales']"
    );
    this.appTilesLocatorInExpandedAppLauncher = this.page.locator(
      "one-app-launcher-app-tile"
    );
  }
  
  async clickOnViewAllButton() {
    await this.clickOn(this.viewAllButtonInAppLauncher);
  }

  async clickOnSalesTilesInExapndedAppLauncher() {
    await this.clickOn(this.salesTileInExpandedAppLauncher);
    return new SalesHomePage(this.page);
  }

  async openAppFromExapandedAppLauncher(appName: AppNameConstant) {
    const appTile = this.appTilesLocatorInExpandedAppLauncher.filter({
      hasText: appName,
    });
    await appTile.click();
    return this.createPageObjectForApp(appName);
  }

  async createPageObjectForApp(appName: AppNameConstant) {
    if (appName === AppNameConstant.SALES) {
      return new SalesHomePage(this.page);
    } else {
      throw new Error(`Page object class do not exist for the app: ${appName}`);
    }
  }
}

import { Locator, Page, expect, test } from "@playwright/test";
import { IComponentAction, LocateBy } from "../IPageActions";

export class BaseComponent {
  constructor(readonly page: Page) {
    this.page = page;
  }

  //making sure my 1 method handles both the conditions
  constructLocatorBasedOnSelector(selector: string) {
    return this.page.locator(selector);
  }
  generateLocator(locateBy: LocateBy) {
    return typeof locateBy === "string"
      ? this.constructLocatorBasedOnSelector(locateBy)
      : locateBy;
  }

  isLocatorVisible(): Promise<boolean> {
    throw new Error("Method not implemented.");
  }
  async clickOn(
    locateBy: LocateBy,
    options?: {
      stepTitle?: string;
      thresholdTimout?: number | undefined;
    }
  ) {
    await test.step(`${options?.stepTitle} : Attempting to click on given locator`, async () => {
      try {
        await this.generateLocator(locateBy).click({
          timeout: options?.thresholdTimout,
        });
      } catch (err) {
        console.log(
          `Error occured while trying to click on given locator : ${err}`
        );
      }
    });
  }

  async fillIn(
    locateBy: Locator | string,
    textToFill: string,
    options?: {
      stepTitle?: string;
      thresholdTimout?: number | undefined;
    }
  ) {
    await test.step(`Trying to enter given text ${textToFill} in the locator`, async () => {
      await this.generateLocator(locateBy).fill(textToFill);
    });
  }

  async verifyTheLocatorIsVisible(
    locateBy: LocateBy,
    assertionStatement: string
  ) {
    await test.step(`Verifying if the locator is visible`, async () => {
      //expect should have an assertion statement
      await expect(
        this.generateLocator(locateBy),
        assertionStatement
      ).toBeVisible();
    });
  }
}

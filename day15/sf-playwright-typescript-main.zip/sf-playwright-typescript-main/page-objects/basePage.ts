import { Page, test, Locator, expect } from "@playwright/test";
import { IPageAction, LocateBy } from "./IPageActions";
import { BaseComponent } from "./ui-components/baseComponent";

export interface IPageAction1 {
  loadThePage(): Promise<void>;

  verifyThePageIsLoaded(): Promise<void>;
}
//understanding of abstract class

/**
 *
 * the abstract are not the complete class on its onw
 * i.e. these are incomplete class
 *
 * these needs to be implemented fully in order to use in real word
 *
 * Restriction -> you can not create an object of abstract class
 *
 *
 */
export abstract class BasePage extends BaseComponent implements IPageAction {
  constructor(page: Page) {
    super(page);
  }

  abstract loadThePage(): Promise<void>;

  abstract verifyThePageIsLoaded(): Promise<void>;

  //main aim of wrapper method is to add extra features and similify the implementation
  async verifyTheUrlIsLoaded(expectedUrl: string, doExactMatch = true) {
    if (doExactMatch) {
      await expect(this.page).toHaveURL(expectedUrl, { timeout: 15000 }); //polling mechanism
    } else {
      //custom assertions using retry mechanism/ polling mechanism
      expect
        .poll(
          () => {
            const url = this.page.url();
            return url;
          },
          { message: "", timeout: 20000 }
        )
        .toContain(expectedUrl);
    }
  }

  async loadUrl(url: string) {
    await test.step(`Loading url ${url}`, async () => {
      await this.page.goto(url);
    });
  }
}

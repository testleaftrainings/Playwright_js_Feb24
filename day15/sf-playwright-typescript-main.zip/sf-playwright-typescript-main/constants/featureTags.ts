export enum FeatureTags {
  LOGIN = "@login",
  ACCOUNT_CREATION = "@account-creation",
}

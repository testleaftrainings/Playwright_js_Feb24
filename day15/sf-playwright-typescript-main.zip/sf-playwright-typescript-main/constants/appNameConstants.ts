export enum AppNameConstant {
  SALES = "Sales",
}

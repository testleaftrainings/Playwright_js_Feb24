export enum TabNameConstants {
  ACCOUNT_TAB = "Accounts",
}

export enum URLConstants{
    LOGIN_PAGE = "https://login.salesforce.com/",
    HOME_PAGE = "https://qeagle-dev-ed.lightning.force.com/lightning/setup/SetupOneHome/home"
}
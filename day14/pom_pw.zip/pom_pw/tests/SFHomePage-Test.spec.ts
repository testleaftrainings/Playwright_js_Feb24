import {test} from '@playwright/test'
import { SFHomePage } from '../pages/homePage'
import { SFLoginPage } from '../pages/loginPage';

test.use({storageState:"ss.json"})
test("Login to SalesForce",async({page})=>{

    const hp=new SFHomePage(page);
   // await hp.doLogin("vidyar@testleaf.com","SForce@123");
    await hp.clickAppLauncher("APPLauncher"); 
  
})

import {test} from '@playwright/test'
import { SFHomePage } from '../pages/homePage'
import { SFLoginPage } from '../pages/loginPage';


test("Login to SalesForce",async({page})=>{

    const hp=new SFLoginPage(page);
    
   await hp.doLogin("vidyar@testleaf.com","Sforce@123");
    
})

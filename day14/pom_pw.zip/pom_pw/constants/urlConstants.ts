export enum URLConstants{
    baseUrl="https://login.salesforce.com/",
    homePAgeURl="https://testleaf-da-dev-ed.develop.lightning.force.com/lightning/setup/SetupOneHome/home"
}
import { URLConstants } from "../constants/urlConstants";
import { PlaywrightWrapper } from "../utils/playwrightWrapper";
import{Page} from '@playwright/test';
import { SFHomePage } from "./homePage";

export class SFLoginPage extends PlaywrightWrapper{

   static pageUrl= URLConstants.baseUrl

    constructor(page:Page){
        super(page)
        this.loadApp(SFLoginPage.pageUrl);   
       // this.page.pause();
     
    }
        async doLogin(uname:string,pwd:string){          
        await this.type("#username","Username",uname)
        await this.type("#password","Password" ,pwd)
        await this.click("#Login","Login" ,"Button")
        await this.storageState();
        
       // return new SFHomePage(this.page)
    }

}
import { URLConstants } from "../constants/urlConstants";
import { PlaywrightWrapper } from "../utils/playwrightWrapper";
import { SFLoginPage } from "./loginPage";
import {Page} from '@playwright/test'
//export class SFHomePage extends SFLoginPage
export class SFHomePage extends PlaywrightWrapper{

        static hpURL=URLConstants.homePAgeURl;
        constructor(page:Page){
            super(page)
            this.loadApp(SFHomePage.hpURL);
        }

      async clickAppLauncher(menuName:string){
    await this.click(".slds-icon-waffle",menuName,"Button");
    
 }




}
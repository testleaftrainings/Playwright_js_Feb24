//Create wrapper method using abstract class
import { Page, test } from '@playwright/test'
export abstract class PlaywrightWrapper {


    readonly page: Page //page property

    constructor(page: Page) {
        this.page = page;
    }

    //type , typeandEnter , click, getText -innerText(), loadUrl

    /*
     This function supports to type int he textfield and clears the data
    @->parameter
    @locator->represents the element selector/locator value
    @name->name of the field
    @data ->information send to the textbox
    */
    async typeAndEnter(locator: string, name: string, data: string) {
        await this.page.locator(locator).clear();
        await this.page.locator(locator).fill(data);
        await this.page.keyboard.press("Enter")
    }

    async type(locator: string, name: string, data: string) {
        try {           
                await test.step(`The textbox ${name} field is entered with ${data}`, async () => {
                await this.page.locator(locator).fill(data);
              //  await this.page.screenshot({ path: "./snapshots/pic.png" });
            });
        } catch(error) {
           console.log("enterd the data is not successful")
        }
    }

    async click(locator: string, name: string, eleInfo: string) {
        await this.page.locator(locator).click();
        // const path = "./video"
        // await this.page.video()?.saveAs(path + "sf")  
        }
    async getText(locator: string) {
        await this.page.locator(locator).innerText();
    }


    async loadApp(url: string) {
        try {
            await test.step(`The URL ${url} loaded`, async () => {

                await this.page.goto(url, { timeout: 60000 }); // Increased timeout
            });
        } catch (error) {
            console.error('Error loading the page:', error);
        }
    }

    async storageState(){
        await this.page.context().storageState({path:"./ss.json"})
    }

    }
